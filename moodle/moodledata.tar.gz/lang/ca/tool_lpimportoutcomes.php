<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'tool_lpimportoutcomes', language 'ca', version '3.11'.
 *
 * @package     tool_lpimportoutcomes
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['additionalscaleshelp'] = 'Els resultats escollits comparteixen més d\'una escala. Configureu cadascuna de les escales addicionals següents.';
$string['continuetoframework'] = 'Continueu amb el marc';
$string['createframework'] = 'Crea un marc';
$string['importmore'] = 'Importa\'n més';
$string['importoutcomes'] = 'Importa els resultats';
$string['invalidoutcomefound'] = 'S\'ha trobat un resultat no vàlid';
$string['lpimportoutcomes:outcomesimport'] = 'Importa els resultats';
$string['nextstep'] = 'Pas següent';
$string['noutcomeschosen'] = '{$a} resultat(s) escollit(s)';
$string['outcomessuccessfullyimported'] = 'Els resultats s\'han importat correctament.';
$string['pluginname'] = 'Eina d\'importació de resultats';
$string['selectoutcomes'] = 'Selecciona els resultats';
