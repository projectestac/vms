<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'theme_trema', language 'ca', version '3.11'.
 *
 * @package     theme_trema
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['activecourses'] = 'Cursos actius';
$string['adminarea'] = 'Només els administradors poden veure blocs en aquesta àrea';
$string['advancedsettings'] = 'Configuració avançada';
$string['alert'] = 'Alerta';
$string['backgroundcolor'] = 'Color de fons';
$string['cachedef_dashboardadmin'] = 'Memòria cau pel tauler de l\'administrador';
$string['card'] = 'Targeta';
$string['cardicon'] = 'Icona de la Targeta';
$string['cardicon_desc'] = 'Trobareu la llista de totes les icones de les Fonts Awesome a: <a href="https://fontawesome.com/v4.7.0/icons/" target="_blank">https://fontawesome.com/v4.7.0/icons/</a>';
$string['cardiconcolor'] = 'Color de l\'icona de la Targeta';
$string['cardlink'] = 'Enllaç de la Targeta';
$string['cardsubtitle'] = 'Subtítol de la Targeta';
$string['cardtitle'] = 'Títol de la Targeta';
$string['carrouselbtnclass'] = 'Classe HTML del botó de la pàgina principal';
$string['carrouselbtnclass_desc'] = 'Podeu canviar l\'estil del botó escollint una altra classe';
$string['carrouselbtnhref'] = 'Enllaç del botó {$a}';
$string['carrouselbtnhref_desc'] = 'Enllaç del botó per la imatge de la pàgina principal {$a}.';
$string['carrouselbtntext'] = 'Text del Botó {$a}';
$string['carrouselbtntext_desc'] = 'Text del Botó pel l\'enllaç en la imatge de la pàgina principal {$a}.';
$string['choosereadme'] = 'Trema està construït sobre el nou tema Boost de Moodle, fent servir Bootstrap4 i les plantilles Mustache.';
$string['circlescolor'] = 'Color del cercles';
$string['configtitle'] = 'Trema';
$string['content'] = 'Contingut';
$string['coursescards'] = 'Targetes dels cursos';
$string['defaultfooter'] = 'Peu de pàgina';
$string['defaultfooter_desc'] = 'Contingut predeterminat del peu de pàgina';
$string['defaultfrontpagebody'] = 'Cos de la pàgina principal';
$string['defaultfrontpagebody_desc'] = 'Contingut predeterminat pel cos de la pàgina principal';
$string['defaultfrontpagefooter'] = 'Peu de pàgina de la pàgina principal';
$string['defaultfrontpagefooter_desc'] = 'Contingut predeterminat pel peu de pàgina de la pàgina principal';
$string['diskusage'] = 'Ocupció del disc pel Moodledata';
$string['enableadmindashboard'] = 'Habilita el Tauler d\'Administrador';
$string['enableadmindashboard_desc'] = 'Desmarqueu-ho si voleu amagar l\'àrea al dessota del tauler d\'administració: <img class="img-responsive" src="{$a}"/>';
$string['enablefooterinfo'] = 'Habilita la informació de peu de pàgina i del tema Trema';
$string['enablefooterinfo_desc'] = 'Desmarqueu-ho si voleu amagar l\'àrea del peu de pàgina:  <img class="img-responsive" src="{$a}"/>';
$string['enabletrematopics'] = 'Activeu l\'estil de curs Trema per als temes dels cursos';
$string['enabletrematopics_desc'] = 'Habilita l\'estil de curs de Trema als formats de Tema dels teus cursos';
$string['favicon'] = 'Favicon personalitzat';
$string['favicon_desc'] = 'Pujeu el vostre propi favicon. Ha de ser un arxiu .ico.';
$string['footertitle'] = 'Tema Trema';
$string['frontpagebanner'] = 'Bàner de la pàgina principal.';
$string['frontpagebanner_desc'] = 'Pugeu la imatge a inserir a la pàgina principal. Aquesta reemplaçarà la imatge predeterminada d\'un bosc';
$string['frontpagebuttonclass'] = 'Classe HTML del botó de la pàgina principal';
$string['frontpagebuttonclass_desc'] = 'Podeu canviar l\'estil del botó escollint una altra classe.';
$string['frontpagebuttonhref'] = 'Href del botó de la pàgina principal';
$string['frontpagebuttonhref_desc'] = 'Escolliu el valor de l\'atribut href del botó.';
$string['frontpagebuttontext'] = 'Text del botó de la pàgina principal';
$string['frontpagecards'] = 'Targetes de la pàgina principal';
$string['frontpagecontent'] = 'Contingut de la pàgina principal';
$string['frontpageenablecards'] = 'Habilita les targetes de la pàgina principal';
$string['frontpageenablecards_desc'] = 'Desmarqueu-ho si voleu amagar l\'àrea a sota: <img class="img-responsive" src="{$a}" />';
$string['frontpageimage'] = 'Imatge de la pàgina principal {$a}';
$string['frontpageimage_desc'] = 'Imatge {$a} per mostrar al bàner de la pàgina principal';
$string['frontpageimages'] = 'Imatges de la pàgina principal';
$string['frontpagesubtitle'] = 'Subtítol de la pàgina principal.';
$string['frontpagetitle'] = 'Títol de la pàgina principal.';
$string['generalsettings'] = 'Configuració general';
$string['image'] = 'Imatge {$a}';
$string['imagelink'] = 'Enllaç de la imatge';
$string['imagelink_desc'] = 'Botó amb enllaç en la imatge {$a}';
$string['login'] = 'Inici de sessió';
$string['loginbackgroundimage'] = 'Imatge de fons de l\'inici de sessió';
$string['loginpagestyle'] = 'Estil de la pàgina d\'Inici de sessió';
$string['numberofcards'] = 'Nombre de targetes';
$string['numberofimages'] = 'Nombre d\'imatges al bàner de la pàgina principal';
$string['numberofimages_desc'] = 'Nombre d\'imatges a mostrar al bàner de la pàgina principal. Si n\'hi ha més d\'una es carrega el Carrousel';
$string['particlecircles'] = 'Cercles del Particle.js';
$string['pluginname'] = 'Trema';
$string['preset'] = 'Configuració del tema';
$string['preset_desc'] = 'Trieu una configuració predeterminada per canviar àmpliament l\'aspecte del tema.';
$string['primarycolor'] = 'Color primari';
$string['primarycolor_desc'] = 'El color principal.';
$string['privacy:metadata'] = 'El tema Trema no guarda cap data de l\'usuari.';
$string['rawscss'] = 'SCSS en brut';
$string['rawscss_desc'] = 'Utilitzeu aquest camp per proporcionar codi SCSS o CSS que s\'injectarà al final del full d\'estil.';
$string['rawscsspre'] = 'SCSS en brut inicial';
$string['rawscsspre_desc'] = 'En aquest camp podeu proporcionar un codi SCSS inicialitzador, que s\'injectarà abans que tota la resta. La majoria de les vegades utilitzareu aquest paràmetre per definir variables.';
$string['region-side-admin'] = 'Només administradors';
$string['region-side-pre'] = 'Dreta';
$string['rememberusername'] = 'Recorda l\'usuari';
$string['secondarycolor'] = 'Color secundari';
$string['secondarycolor_desc'] = 'El color secundari.';
$string['seemore'] = 'Veure\'n més';
$string['showmycourses'] = 'Mostra els meus cursos';
$string['showmycourses_desc'] = 'Mostra els cursos inscrits a la barra de navegació';
$string['styleguide'] = 'Guia d\'estil';
$string['subtitle'] = 'Subtítol';
$string['subtitle_desc'] = 'Subtítol que es mostra a la imatge de la pàgina principal {$a}';
$string['summarybutton_text'] = 'Descripció del curs';
$string['summarycourselink_text'] = 'Ves al Curs';
$string['summarytype'] = 'Tipus de resum';
$string['summarytype_desc'] = 'Trieu si el resum del curs s\'obrirà de manera modal o emergent.';
$string['systemsecurity'] = 'Seguretat del Sistema';
$string['title'] = 'Títol';
$string['title_desc'] = 'Títol a mostrar a la imatge de la pàgina principal {$a}';
$string['total'] = 'Total';
