<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'theme_adaptable', language 'ca', version '3.11'.
 *
 * @package     theme_adaptable
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['aboutme'] = 'Sobre mi';
$string['actingasrole'] = 'Actualment esteu actuant amb un rol diferent';
$string['activatetemplateoverride'] = 'Activa la substitució de plantilla per a «{$a}»';
$string['activatetemplateoverridedesc'] = 'Quan estigui marcat, el valor del paràmetre «{$a->setting}» s\'utilitzarà com a plantilla «{$a->template}» si conté text.';
$string['activebreadcrumb'] = 'Color de fons del fil d\'ariadna actiu';
$string['activebreadcrumbdesc'] = 'Estableix el color de fons del color del fil d\'ariadna actiu i la resta de la barra del fil d\'ariadna.';
$string['activitiesheading'] = 'Activitats';
$string['alertaccess'] = 'Visibilitat de l\'alerta';
$string['alertaccessadmins'] = 'Visible per als administradors';
$string['alertaccessdesc'] = 'Estableix el tipus de restricció d\'accés per a la visibilitat del quadre d\'alerta. Nota: si utilitzeu «Afegeix una restricció de camp de perfil personalitzat» haureu d\'afegir valors per als camps de perfil del dessota.';
$string['alertaccessglobal'] = 'Visible per a tothom';
$string['alertaccessprofile'] = 'Afegieix una restricció de camp de perfil personalitzat';
$string['alertaccessusers'] = 'Visible per als usuaris connectats';
$string['alertannounce'] = 'Anunci';
$string['alertannouncedesc'] = 'Mostra un anunci al quadre d\'alerta.';
$string['alertbackgroundcolorinfo'] = 'Color de fons de les informacions';
$string['alertbackgroundcolorinfodesc'] = 'Color de fons dels quadres d\'alerta de tipus Informació.';
$string['alertbackgroundcolorsuccess'] = 'Color de fons de l\'anunci';
$string['alertbackgroundcolorsuccessdesc'] = 'Color de fons dels quadres d\'alerta de tipus Anunci.';
$string['alertbackgroundcolorwarning'] = 'Color de fons d’advertència';
$string['alertbackgroundcolorwarningdesc'] = 'Color de fons dels quadres d\'alerta de tipus Advertiment.';
$string['alertbordercolorinfo'] = 'Color de la vora de la informació';
$string['alertbordercolorinfodesc'] = 'Color de la vora dels quadres d\'alerta de tipus Informació.';
$string['alertbordercolorsuccess'] = 'Color de la vora de l\'anunci';
$string['alertbordercolorsuccessdesc'] = 'Color de la vora dels quadres de tipus d\'alerta de l\'anunci';
$string['alertbordercolorwarning'] = 'Color de la vora de l’advertència';
$string['alertbordercolorwarningdesc'] = 'Color de la vora dels quadres d\'alerta de tipus Advertiment.';
$string['alertcolorinfo'] = 'Color de la informació';
$string['alertcolorinfodesc'] = 'Color de la icona dels quadres d\'alerta del tipus Informació.';
$string['alertcolorsheading'] = 'Personalitza els quadres d\'alerta superior';
$string['alertcolorsheadingdesc'] = 'Estableix els colors i la icona.';
$string['alertcolorsuccess'] = 'Color de l\'anunci';
$string['alertcolorsuccessdesc'] = 'Color de la icona dels quadres de tipus d\'alerta de l\'anunci';
$string['alertcolorwarning'] = 'Color de les advertències';
$string['alertcolorwarningdesc'] = 'Color de la icona dels quadres d\'alerta del tipus Advertiment.';
$string['alertcount'] = 'Recompte d\'alertes';
$string['alertcountdesc'] = 'El nombre d\'alertes que es mostraran a l\'àrea d\'edició següent.';
$string['alertdesc'] = 'Introduïu i personalitzeu el text que es mostrarà a la part superior del lloc com a alerta. És possible d\'establir més d\'una alerta per adreçar-se a diferents tipus d\'usuaris. També teniu l\'opció de mostrar alertes a tot el lloc o només a les pàgines d\'inici.<br /> <br /> <strong> Nota: </strong> ara també és possible mostrar alertes a les pàgines del curs per advertir als professors que els cursos estan amagats.';
$string['alertdisabled'] = 'Desactivada';
$string['alertdisabledesc'] = 'Desactiveu aquesta alerta.';
$string['alerthiddencourse'] = 'Activa les alertes de curs';
$string['alerthiddencoursedesc'] = 'Mostra les alertes a la pàgina del curs.';
$string['alerthiddencoursetext-1'] = 'Aquest curs està amagat i els estudiants no hi poden accedir.';
$string['alerthiddencoursetext-2'] = 'Feu clic aquí per actualitzar la configuració';
$string['alerticoninfo'] = 'Icona d\'informació';
$string['alerticoninfodesc'] = 'Establiu la «<a href="https://fontawesome.com/v5.15/icons?d=gallery&p=2&m=free">Icona Font Awesome</a>» per utilitzar-la als quadres d\'alerta del tipus Informació. Introduïu el nom de la icona sense el prefix fa- .';
$string['alerticonsuccess'] = 'Icona de l\'anunci';
$string['alerticonsuccessdesc'] = 'Configura les icones<a href="http://fortawesome.github.io/Font-Awesome/icons/">Font Awesome Icons</a> per emprar-les als quadres de tipus d\'alerta de l\'anunci. Introdueix el nom de la icona sense el prefix fa-.';
$string['alerticonwarning'] = 'Icona d\'advertència';
$string['alerticonwarningdesc'] = 'Establiu la "<a href="https://fontawesome.com/v5.15/icons?d=gallery&p=2&m=free">Font Awesome Icon</a> per utilitzar-la als quadres d\'alerta del tipus Advertiment. Introduïu el nom de la icona sense el prefix fa- .';
$string['alertinfo'] = 'Info';
$string['alertinfodesc'] = 'Mostra la informació al quadre d\'alerta.';
$string['alertkeyvalue'] = 'Clau d\'alerta';
$string['alertkeyvalue_details'] = 'La clau que identifica aquesta alerta, a partir d\'alertes anteriors. Si canvieu això, tots els usuaris que hagin rebutjat l\'alerta anteriorment la tornaran a veure. Si canvieu l\'alerta, és probable que vulgueu canviar-la per garantir que tots els usuaris la vegin.';
$string['alertprofilefield'] = 'Nom del camp del perfil personalitzat = Valor (opcional)';
$string['alertprofilefielddesc'] = 'Afegiu una regla d\'accés mitjançant un camp de perfil personalitzat, per exemple: usertype = student.';
$string['alertsettings'] = 'Caixa d\'alertes {$a}';
$string['alertsettingscourse'] = 'Configuració d\'alertes del curs';
$string['alertsettingsgeneral'] = 'Configuració general d\'alertes';
$string['alertsettingsheading'] = 'Personalitzeu el quadre d\'alertes superior. Consulteu el disseny <a href="./../theme/adaptable/pix/layout.png" target="_blank">aquí</a>';
$string['alerttext'] = 'Text d\'alerta';
$string['alerttextdesc'] = 'Introduïu el text que es mostrarà al quadre d\'alerta.';
$string['alerttype'] = 'Tipus de quadre d\'alerta';
$string['alerttypedesc'] = 'Selecciona el tipus d\'alerta: informació (blau), avís (groc) o anunci (ver)';
$string['alertwarning'] = 'Avís';
$string['alertwarningdesc'] = 'Mostra un avís al quadre d\'alerta.';
$string['analyticscount'] = 'Recompte d’anàlisis';
$string['analyticscountdesc'] = 'El nombre de camps d\'anàlisi que es mostraran a l\'àrea d\'edició següent.';
$string['analyticsprofilefield'] = 'Nom del camp del perfil personalitzat = Valor (opcional)';
$string['analyticsprofilefielddesc'] = 'Afegiu una regla d\'accés mitjançant un camp de perfil personalitzat, per exemple: usertype = student.';
$string['analyticssettings'] = 'Analytics';
$string['analyticssettingsdesc'] = 'Podeu configurar diversos codis per a Google Analytics i orientar-los als camps del perfil d\'usuari. O podeu utilitzar Matomo, l’anàlisi de codi obert.';
$string['analyticssettingsheading'] = 'Configureu Google Analytics i/o Matomo';
$string['analyticstext'] = 'ID d\'Analytics';
$string['analyticstextdesc'] = 'Introduïu l\'ID de Google Analytics.';
$string['anonymizega'] = 'Anonimitza la IP de l\'usuari';
$string['anonymizegadesc'] = 'Anonimitza l’adreça IP de l’usuari enviada a Google Analytics.';
$string['backcolor'] = 'Color del fons';
$string['backcolordesc'] = 'Estableix el color de fons.';
$string['bcustyle'] = 'Estil BCU';
$string['beta'] = 'VERSIÓ DE DESENVOLUPAMENT. NO L\'USEU EN LLOCS DE PRODUCCIÓ';
$string['blockbackgroundcolor'] = 'Color del fons del bloc';
$string['blockbackgroundcolordesc'] = 'Ajusta el color de fons de tots els blocs';
$string['blockbordercolor'] = 'Color de la vora del bloc';
$string['blockbordercolordesc'] = 'Ajusta el color de la vora del bloc';
$string['blockheaderbackgroundcolor'] = 'Color del fons de la capçalera del bloc';
$string['blockheaderbackgroundcolordesc'] = 'Ajusta el color de fons de la capçalera de tots els blocs';
$string['blockheaderborderbottom'] = 'Gruix de la vora inferior de la capçalera del bloc';
$string['blockheaderborderbottomdesc'] = 'Definiu el gruix de la vora inferior de les capçaleres de blocs.';
$string['blockheaderborderleft'] = 'Gruix de la vora esquerra de la capçalera del bloc';
$string['blockheaderborderleftdesc'] = 'Definiu el gruix de la vora esquerre de les capçaleres de blocs.';
$string['blockheaderborderright'] = 'Gruix de la vora dreta de la capçalera del bloc';
$string['blockheaderborderrightdesc'] = 'Estableix el gruix de la vora dreta de les capçaleres de blocs.';
$string['blockheaderbordertop'] = 'Gruix de la vora superior de la capçalera del bloc';
$string['blockheaderbordertopdesc'] = 'Definiu el gruix de la vora superior de les capçaleres de blocs.';
$string['blockheaderbordertopstyle'] = 'Estil de la vora de la capçalera del bloc';
$string['blockheaderbordertopstyledesc'] = 'Definiu l\'estil de la vora de capçaleres de blocs.';
$string['blockheaderbottomradius'] = 'Radi de la vora inferior de la capçalera del bloc';
$string['blockheaderbottomradiusdesc'] = 'Establiu el radi del bloc de capçalera inferior per aconseguir un efecte corbat / arrodonit.';
$string['blockheadercolor'] = 'Color de la lletra de la capçalera del bloc';
$string['blockheadercolordesc'] = 'Establiu el color de la font de la capçalera del bloc.';
$string['blockheadertopradius'] = 'Radi de la vora superior de la capçalera del bloc';
$string['blockheadertopradiusdesc'] = 'Establiu el radi del bloc de capçalera superior per aconseguir un efecte corbat / arrodonit.';
$string['blockicons'] = 'Icones del bloc';
$string['blockiconsdesc'] = 'Establiu-lo per mostrar les icones de bloc a l\'àrea de capçalera del bloc.';
$string['blockiconsheadersize'] = 'Mida de la icona de capçalera de blocs';
$string['blockiconsheadersizedesc'] = 'Definiu la mida de la icona de tipus de lletra que s\'utilitza a la capçalera dels blocs moodle. Seleccioneu un valor de la llista.';
$string['blocklayoutbuilder'] = 'Regions per a blocs de la pàgina d\'inici';
$string['blocklayoutbuilderdesc'] = 'Al dessota podeu crear el vostre propi disseny per a regions de blocs a la pàgina inicial. <br/> Per afegir contingut a aquestes regions, haureu <strong> d’activar l’edició a la pàgina inicial de Moodle </strong>.<br/> Aleshores podeu començar a arrossegar / deixar anar blocs a les regions que creeu.';
$string['blocklayoutlayoutcheck'] = 'Comproveu la vostra disposició';
$string['blocklayoutlayoutcheckdesc'] = 'Feu servir l\'eina del dessota per comprovar el nombre de blocs que heu emprat i veure una representació de la nova disposició.';
$string['blocklayoutlayoutcount1'] = 'Podeu establir fins a';
$string['blocklayoutlayoutcount2'] = 'regions de blocs. Ara n\'esteu emprant:';
$string['blocklayoutlayoutrow'] = 'Fila de la regió de blocs';
$string['blocklayoutlayoutrowdesc'] = 'Afegeix / configura el disseny de la fila de la regió de blocs a la pàgina inicial.';
$string['blockmainborderbottom'] = 'Bloca el gruix de la vora inferior principal';
$string['blockmainborderbottomdesc'] = 'Estableix el gruix de la vora inferior de l\'àrea del bloc principal.';
$string['blockmainborderleft'] = 'Bloca el gruix de la vora esquerra principal';
$string['blockmainborderleftdesc'] = 'Estableix el gruix de la vora esquerra de l\'àrea del bloc principal.';
$string['blockmainborderright'] = 'Bloca el gruix de la vora dreta principal';
$string['blockmainborderrightdesc'] = 'Estableix el gruix de la vora dreta de l\'àrea del bloc principal.';
$string['blockmainbordertop'] = 'Bloca el gruix de la vora superior principal';
$string['blockmainbordertopdesc'] = 'Estableix el gruix del límit superior de l\'àrea del bloc principal.';
$string['blockmainbordertopstyle'] = 'Bloca l\'estil de vora principal';
$string['blockmainbordertopstyledesc'] = 'Defineix l\'estil de la vora de l\'àrea de contingut del bloc.';
$string['blockmainbottomradius'] = 'Bloca el radi inferior inferior';
$string['blockmainbottomradiusdesc'] = 'Estableix el radi inferior de l\'àrea del bloc principal per aconseguir un efecte corbat / arrodonit.';
$string['blockmaintopradius'] = 'Bloca el radi superior principal';
$string['blockmaintopradiusdesc'] = 'Estableix el radi superior de l\'àrea del bloc principal per aconseguir un efecte corbat / arrodonit.';
$string['blockregionbackground'] = 'Bloca el color de fons de la regió';
$string['blockregionbackgrounddesc'] = 'Color de fons del contenidor que conté dissenys de blocs personalitzats a la pàgina inicial.';
$string['blocksettings'] = 'Opcions dels blocs';
$string['blockside'] = 'Ubicació dels blocs';
$string['blocksidedesc'] = 'Controla si els blocs apareixen a l\'esquerra o a la dreta de la pàgina.';
$string['breadcrumb'] = 'Fil d\'Ariadna';
$string['breadcrumbbackgroundcolor'] = 'Color de fons del fil d\'Ariadna';
$string['breadcrumbbackgroundcolordesc'] = 'Defineix el color de fons del fil d\'Ariadna';
$string['breadcrumbdisplay'] = 'Visualització del fil d\'Ariadna';
$string['breadcrumbdisplaydesc'] = 'Estableix la visualització de què s\'hauria de mostrar a la zona del fil d\'Ariadna en un curs.';
$string['breadcrumbhomeicon'] = 'Icona';
$string['breadcrumbhometext'] = 'Text';
$string['bs4all'] = 'Extra petit - Extra gran';
$string['bs4extralarge'] = 'Només molt gran';
$string['bs4large'] = 'Gran - Molt gran';
$string['bs4medium'] = 'Mitjà -  Molt gran';
$string['bs4none'] = 'Cap';
$string['bs4small'] = 'Petit -  Molt gran';
$string['buttoncolor'] = 'Color del botó';
$string['buttoncolorcancel'] = 'Color del botó Cancel·la';
$string['buttoncolordesc'] = 'El color dels botons principals utilitzats a tot el lloc.';
$string['buttoncolordesccancel'] = 'Color de fons del botó Cancel·la. <br />Escriviu transparent a la caixa per obtenir transparència.';
$string['buttoncolordescscnd'] = 'El color dels botons secundaris utilitzats a tot el lloc.';
$string['buttoncolorscnd'] = 'Color del botó secundari';
$string['buttondesc'] = 'Modifiqueu l\'aparença dels botons que s\'utilitzen en aquest tema.';
$string['buttondropshadow'] = 'Decoració de les ombres a la part inferior del botó';
$string['buttondropshadowdesc'] = 'Mostra una ombra (ombrejat) a la part inferior del botó.';
$string['buttonhovercolor'] = 'Color del botó quan se sobrevola';
$string['buttonhovercolorcancel'] = 'Color del botó Cancel·la quan se sobrevola';
$string['buttonhovercolordesc'] = 'El color al qual canvia el botó quan es passa el cursor per sobre del botó.';
$string['buttonhovercolordesccancel'] = 'El color al qual canvia el botó de cancel·lació quan es passa el cursor per sobre del botó. <br /> Escriviu transparent al quadre per obtenir transparència.';
$string['buttonhovercolordescscnd'] = 'El color al qual canvia el botó secundari quan es passa el cursor per sobre del botó.';
$string['buttonlogincolor'] = 'Color del botó d\'inici de sessió';
$string['buttonlogincolordesc'] = 'El color del botó d\'inici de sessió.';
$string['buttonloginheight'] = 'Definiu l\'alçada del botó d\'inici de sessió';
$string['buttonloginheightdesc'] = 'Només serà efectiu si s’utilitza un formulari d’inici de sessió a la capçalera superior.';
$string['buttonloginmargintop'] = 'Establiu el marge superior del botó d\'inici de sessió';
$string['enablemy'] = 'El meu tauler';
$string['enablemydesc'] = 'Mostra un enllaç al meu tauler';
$string['events'] = 'Events';
$string['fontcolor'] = 'Color del tipus de lletra principal';
$string['footnote'] = 'Nota a peu de pàgina';
$string['logo'] = 'Logotip';
$string['myblogs'] = 'Els meus blogs';
$string['mysites'] = 'Els meus cursos';
$string['noenrolments'] = 'No s\'ha trobat cap inscripció.';
$string['region-side-pre'] = 'Esquerra';
$string['ticker'] = 'Anuncis';
